FORM v6 — GitHub Pages setup

Upload the CONTENTS of this folder to the root of your GitHub Pages repository.
Required root files: index.html, manifest.webmanifest, sw.js, and icons/ folder.
On GitHub: Settings > Pages > Deploy from branch > main > /(root).
On iPhone: Open the published URL in Safari > Share > Add to Home Screen.

Existing v5 daily entries in the same browser and domain are imported automatically on first use.
Data is local to the browser; use Export backup for safekeeping.
Offline mode is available after the app is visited once while online and cached.
